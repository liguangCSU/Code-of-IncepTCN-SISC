from __future__ import print_function
import tensorflow as tf
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D
import pickle
from keras.models import Model
from keras.layers import add, Input, Conv1D, Activation, Flatten, Dense, Dropout, MaxPooling1D, AveragePooling1D
#\SeparableConv1D
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import OneHotEncoder
from keras import optimizers
import pickle
import keras
import keras.backend as K
import time
# tf.random.set_seed(7)
np.random.seed(22)

start = time.time()
print("start Training!")
################batch大小，每处理**个样本进行一次梯度更新############
#超参数的设置
batch_size = 128
num_classes = 2
epochs = 100

length = 1200
channel = 1

# 载入数据

train_x = np.loadtxt('Samplelibrary7-2.dat')
train_y = np.loadtxt('Samplelabel7-2.dat')

train_x = train_x.reshape(-1, length, channel)

test_x = np.loadtxt('Raw_T(HDL1--001--003)_(L1-2)_(D83-1)_F(7-2)_A3_C1_FFT.dat')
test_y = np.loadtxt('Raw_T(HDL1--001--003)_(L1-2)_(D83-1)_F(7-2)_A3_C1_label2.dat')
test_x = test_x.reshape(-1, length, channel)

mc = test_x
mc = mc.reshape(-1, length, channel)
mc = np.array(mc)

for i in range(len(test_x)):
    test_x[i] = (test_x[i] - np.min(test_x[i])) / (np.max(test_x[i]) - np.min(test_x[i]))
    # test_x[i] = (test_x[i] - np.mean(test_x[i])) / np.std(test_x[i])

for i in range(len(train_x)):
    train_x[i] = (train_x[i] - np.min(train_x[i])) / (np.max(train_x[i]) - np.min(train_x[i]))
    # train_x[i] = (train_x[i] - np.mean(train_x[i])) / np.std(train_x[i])

va1 = np.loadtxt('Raw_T(HDL1--001--003)_(L1-3)_(D80-1)_F(7-2)_A3_C1_FFT.dat')
va1 = va1.reshape(-1, length, channel)
va2 = np.loadtxt('Raw_T(HDL1--3--5)_(L1-4)_(D80-1)_F(7-2)_A2_C1_FFT.dat')
va2 = va2.reshape(-1, length, channel)
va3 = np.loadtxt('Raw_T(hdl1-008-007-1)_(L1-8)_(D84-1)_F(7-2)_A2_C1_FFT.dat')
va3 = va3.reshape(-1, length, channel)
va4 = np.loadtxt('sample1-5.dat')
va4 = va4.reshape(-1, length, channel)
va5 = np.loadtxt('sample1-9.dat')
va5 = va5.reshape(-1, length, channel)
va6 = np.loadtxt('Raw_T(HDL1013-014)_(L1-13)_(D100-2)_F(7-2)_A1_C1_FFT.dat')
va6 = va6.reshape(-1, length, channel)
va7 = np.loadtxt('Raw_T(HDL1013-014)_(L1-14)_(D93-2)_F(7-2)_A1_C1_FFT.dat')
va7 = va7.reshape(-1, length, channel)

va8 = np.loadtxt('Raw_T(QJL1002-003)_(L1-3)_(D100-1)_F(7-2)_A5_C1_FFT.dat')
va8 = va8.reshape(-1, length, channel)
va9 = np.loadtxt('Raw_T(QJL1004-006)_(L1-4)_(D98-1)_F(7-2)_A8_C1_FFT.dat')
va9 = va9.reshape(-1, length, channel)
va10 = np.loadtxt('Raw_T(QJ011-012)_(L1-11)_(D93-2)_F(7-2)_A4_C1_FFT.dat')
va10 = va10.reshape(-1, length, channel)
va11 = np.loadtxt('Raw_T(QJ011-012)_(L1-12)_(D83-1)_F(7-2)_A4_C1_FFT.dat')
va11 = va11.reshape(-1, length, channel)
va12 = np.loadtxt('Raw_T(QJ 013-014)_(L1-13)_(D93-1)_F(7-2)_A4_C1_FFT.dat')
va12 = va12.reshape(-1, length, channel)
va13 = np.loadtxt('Raw_T(QJ 013-014)_(L1-14)_(D83-1)_F(7-2)_A4_C1_FFT.dat')
va13 = va13.reshape(-1, length, channel)
va14 = np.loadtxt('Raw_T(QJ030-032)_(L1-31)_(D83-1)_F(7-2)_A1_C1_FFT.dat')
va14 = va14.reshape(-1, length, channel)
va15 = np.loadtxt('Raw_T(QJ030-032)_(L1-32)_(D95-1)_F(7-2)_A1_C1_FFT.dat')
va15 = va15.reshape(-1, length, channel)
va16 = np.loadtxt('Raw_T(QJL1033-035)_(L1-33)_(D90-1)_F(7-2)_A2_C1_FFT.dat')
va16 = va16.reshape(-1, length, channel)

mc1 = va1
mc1 = mc1.reshape(-1, length, channel)
mc1 = np.array(mc1)

mc2 = va2
mc2 = mc2.reshape(-1, length, channel)
mc2 = np.array(mc2)

mc3 = va3
mc3 = mc3.reshape(-1, length, channel)
mc3 = np.array(mc3)

mc4 = va4
mc4 = mc4.reshape(-1, length, channel)
mc4 = np.array(mc4)

mc5 = va5
mc5 = mc5.reshape(-1, length, channel)
mc5 = np.array(mc5)

mc6 = va6
mc6 = mc6.reshape(-1, length, channel)
mc6 = np.array(mc6)

mc7 = va7
mc7 = mc7.reshape(-1, length, channel)
mc7 = np.array(mc7)

mc8 = va8
mc8 = mc8.reshape(-1, length, channel)
mc8 = np.array(mc8)

mc9 = va9
mc9 = mc9.reshape(-1, length, channel)
mc9 = np.array(mc9)

mc10 = va10
mc10 = mc10.reshape(-1, length, channel)
mc10 = np.array(mc10)

mc11 = va11
mc11 = mc11.reshape(-1, length, channel)
mc11 = np.array(mc11)

mc12 = va12
mc12 = mc12.reshape(-1, length, channel)
mc12 = np.array(mc12)

mc13 = va13
mc13 = mc13.reshape(-1, length, channel)
mc13 = np.array(mc13)

mc14 = va14
mc14 = mc14.reshape(-1, length, channel)
mc14 = np.array(mc14)

mc15 = va15
mc15 = mc15.reshape(-1, length, channel)
mc15 = np.array(mc15)

mc16 = va16
mc16 = mc16.reshape(-1, length, channel)
mc16 = np.array(mc16)

for i in range(len(va1)):
    va1[i] = (va1[i] - np.min(va1[i])) / (np.max(va1[i]) - np.min(va1[i]))
    # va[i] = (va[i] - np.mean(va[i])) / np.std(va[i])

for i in range(len(va2)):
    va2[i] = (va2[i] - np.min(va2[i])) / (np.max(va2[i]) - np.min(va2[i]))
    # va2[i] = (va2[i] - np.mean(va2[i])) / np.std(va2[i])

for i in range(len(va3)):
    va3[i] = (va3[i] - np.min(va3[i])) / (np.max(va3[i]) - np.min(va3[i]))
    # va3[i] = (va3[i] - np.mean(va3[i])) / np.std(va3[i])

for i in range(len(va4)):
    va4[i] = (va4[i] - np.min(va4[i])) / (np.max(va4[i]) - np.min(va4[i]))
    # va4[i] = (va4[i] - np.mean(va4[i])) / np.std(va4[i])

for i in range(len(va5)):
    va5[i] = (va5[i] - np.min(va5[i])) / (np.max(va5[i]) - np.min(va5[i]))
    # va5[i] = (va5[i] - np.mean(va5[i])) / np.std(va5[i])

for i in range(len(va6)):
    va6[i] = (va6[i] - np.min(va6[i])) / (np.max(va6[i]) - np.min(va6[i]))
    # va6[i] = (va6[i] - np.mean(va6[i])) / np.std(va6[i])

for i in range(len(va7)):
    va7[i] = (va7[i] - np.min(va7[i])) / (np.max(va7[i]) - np.min(va7[i]))
    # va7[i] = (va7[i] - np.mean(va7[i])) / np.std(va7[i])

for i in range(len(va8)):
    va8[i] = (va8[i] - np.min(va8[i])) / (np.max(va8[i]) - np.min(va8[i]))
    # va8[i] = (va8[i] - np.mean(va8[i])) / np.std(va8[i])

for i in range(len(va9)):
    va9[i] = (va9[i] - np.min(va9[i])) / (np.max(va9[i]) - np.min(va9[i]))
    # va9[i] = (va9[i] - np.mean(va9[i])) / np.std(va9[i])

for i in range(len(va10)):
    va10[i] = (va10[i] - np.min(va10[i])) / (np.max(va10[i]) - np.min(va10[i]))
    # va10[i] = (va10[i] - np.mean(va10[i])) / np.std(va10[i])

for i in range(len(va11)):
    va11[i] = (va11[i] - np.min(va11[i])) / (np.max(va11[i]) - np.min(va11[i]))
    # va11[i] = (va11[i] - np.mean(va11[i])) / np.std(va11[i])

for i in range(len(va12)):
    va12[i] = (va12[i] - np.min(va12[i])) / (np.max(va12[i]) - np.min(va12[i]))
    # va12[i] = (va12[i] - np.mean(va12[i])) / np.std(va12[i])

for i in range(len(va13)):
    va13[i] = (va13[i] - np.min(va13[i])) / (np.max(va13[i]) - np.min(va13[i]))
    # va13[i] = (va13[i] - np.mean(va13[i])) / np.std(va13[i])

for i in range(len(va14)):
    va14[i] = (va14[i] - np.min(va14[i])) / (np.max(va14[i]) - np.min(va14[i]))
    # va14[i] = (va14[i] - np.mean(va14[i])) / np.std(va14[i])

for i in range(len(va15)):
    va15[i] = (va15[i] - np.min(va15[i])) / (np.max(va15[i]) - np.min(va15[i]))
    # va15[i] = (va15[i] - np.mean(va15[i])) / np.std(va15[i])

for i in range(len(va16)):
    va16[i] = (va16[i] - np.min(va16[i])) / (np.max(va16[i]) - np.min(va16[i]))
    # va16[i] = (va16[i] - np.mean(va16[i])) / np.std(va16[i])

vy = np.loadtxt('Raw_T(HDL1--001--003)_(L1-3)_(D80-1)_F(7-2)_A3_C1_label2.dat')
vy2 = np.loadtxt('Raw_T(HDL1--3--5)_(L1-4)_(D80-1)_F(7-2)_A2_C1_label2.dat')
vy3 = np.loadtxt('Raw_T(hdl1-008-007-1)_(L1-8)_(D84-1)_F(7-2)_A2_C1_label2.dat')
vy4 = np.loadtxt('samplelabel1-5_2.dat')
vy5 = np.loadtxt('samplelabel1-9_2.dat')
vy6 = np.loadtxt('Raw_T(HDL1013-014)_(L1-13)_(D100-2)_F(7-2)_A1_C1_label2.dat')
vy7 = np.loadtxt('Raw_T(HDL1013-014)_(L1-14)_(D93-2)_F(7-2)_A1_C1_label2.dat')

vy8 = np.loadtxt('Raw_T(QJL1002-003)_(L1-3)_(D100-1)_F(7-2)_A5_C1_label2.dat')
vy9 = np.loadtxt('Raw_T(QJL1004-006)_(L1-4)_(D98-1)_F(7-2)_A8_C1_label2.dat')
vy10 = np.loadtxt('Raw_T(QJ011-012)_(L1-11)_(D93-2)_F(7-2)_A4_C1_label2.dat')
vy11 = np.loadtxt('Raw_T(QJ011-012)_(L1-12)_(D83-1)_F(7-2)_A4_C1_label2.dat')
vy12 = np.loadtxt('Raw_T(QJ 013-014)_(L1-13)_(D93-1)_F(7-2)_A4_C1_label.dat')
vy13 = np.loadtxt('Raw_T(QJ 013-014)_(L1-14)_(D83-1)_F(7-2)_A4_C1_label.dat')
vy14 = np.loadtxt('Raw_T(QJ030-032)_(L1-31)_(D83-1)_F(7-2)_A1_C1_label2.dat')
vy15 = np.loadtxt('Raw_T(QJ030-032)_(L1-32)_(D95-1)_F(7-2)_A1_C1_label2.dat')
vy16 = np.loadtxt('Raw_T(QJL1033-035)_(L1-33)_(D90-1)_F(7-2)_A2_C1_label2.dat')

ohe = OneHotEncoder()
ohe.fit([[0], [1]])
train_y = ohe.transform(train_y.reshape(-1, 1)).toarray()
test_y = ohe.transform(test_y.reshape(-1, 1)).toarray()
vy = ohe.transform(vy.reshape(-1, 1)).toarray()
vy2 = ohe.transform(vy2.reshape(-1, 1)).toarray()
vy3 = ohe.transform(vy3.reshape(-1, 1)).toarray()
vy4 = ohe.transform(vy4.reshape(-1, 1)).toarray()
vy5 = ohe.transform(vy5.reshape(-1, 1)).toarray()
vy6 = ohe.transform(vy6.reshape(-1, 1)).toarray()
vy7 = ohe.transform(vy7.reshape(-1, 1)).toarray()
vy8 = ohe.transform(vy8.reshape(-1, 1)).toarray()
vy9 = ohe.transform(vy9.reshape(-1, 1)).toarray()
vy10 = ohe.transform(vy10.reshape(-1, 1)).toarray()
vy11 = ohe.transform(vy11.reshape(-1, 1)).toarray()
vy12 = ohe.transform(vy12.reshape(-1, 1)).toarray()
vy13 = ohe.transform(vy13.reshape(-1, 1)).toarray()
vy14 = ohe.transform(vy14.reshape(-1, 1)).toarray()
vy15 = ohe.transform(vy15.reshape(-1, 1)).toarray()
vy16 = ohe.transform(vy16.reshape(-1, 1)).toarray()


model = Sequential()
start = time.clock()
inputs = (length, channel)
model.add(Conv1D(32, kernel_size=3,
                 activation='relu',
                 input_shape=inputs))
# model.add(BatchNormalization())
model.add(Conv1D(32, kernel_size=3, activation='relu'))
# model.add(BatchNormalization())
model.add(MaxPooling1D(pool_size=2))
model.add(Conv1D(64, kernel_size=3,
                 activation='relu'))
#                    model.add(BatchNormalization())
model.add(Conv1D(64, kernel_size=3,
                 activation='relu'))
#                    model.add(BatchNormalization())
model.add(MaxPooling1D(pool_size=2))
model.add(Flatten())             			##Flatten层用来将输入“压平”，
##即把多维的输入一维化，常用在
##从卷积层到全连接层的过渡。
##Flatten不影响batch的大小。
model.add(Dense(num_classes, activation='softmax'))
model.summary() #查看网络结构

reduce_lr = keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=1, verbose=2, min_lr=1e-10)
# , callbacks = [reduce_lr]
# 编译模型
model.compile(optimizer=optimizers.Adam(lr=1e-5), loss='categorical_crossentropy', metrics=['accuracy'])
# 训练模型
history = model.fit(train_x, train_y, batch_size=128, epochs=100, verbose=2, validation_split=0.1,
                    callbacks=[reduce_lr])  # validation_data=(valid_x, valid_y)
print(time.clock() - start)

pre = model.evaluate(test_x, test_y, batch_size=50, verbose=2)
pre1 = model.evaluate(va1, vy, batch_size=50, verbose=2)
pre2 = model.evaluate(va2, vy2, batch_size=50, verbose=2)
pre3 = model.evaluate(va3, vy3, batch_size=50, verbose=2)
pre4 = model.evaluate(va4, vy4, batch_size=50, verbose=2)
pre5 = model.evaluate(va5, vy5, batch_size=50, verbose=2)
pre6 = model.evaluate(va6, vy6, batch_size=50, verbose=2)
pre7 = model.evaluate(va7, vy7, batch_size=50, verbose=2)
pre8 = model.evaluate(va8, vy8, batch_size=50, verbose=2)
pre9 = model.evaluate(va9, vy9, batch_size=50, verbose=2)
pre10 = model.evaluate(va10, vy10, batch_size=50, verbose=2)
pre11 = model.evaluate(va11, vy11, batch_size=50, verbose=2)
pre12 = model.evaluate(va12, vy12, batch_size=50, verbose=2)
pre13 = model.evaluate(va13, vy13, batch_size=50, verbose=2)
pre14 = model.evaluate(va14, vy14, batch_size=50, verbose=2)
pre15 = model.evaluate(va15, vy15, batch_size=50, verbose=2)
pre16 = model.evaluate(va16, vy16, batch_size=50, verbose=2)

print('test_loss:', pre[0], '- test_acc:', pre[1])
print('test_loss:', pre1[0], '- test_acc:', pre1[1])
print('test_loss:', pre2[0], '- test_acc:', pre2[1])
print('test_loss:', pre3[0], '- test_acc:', pre3[1])
print('test_loss:', pre4[0], '- test_acc:', pre4[1])
print('test_loss:', pre5[0], '- test_acc:', pre5[1])
print('test_loss:', pre6[0], '- test_acc:', pre6[1])
print('test_loss:', pre7[0], '- test_acc:', pre7[1])
print('test_loss:', pre8[0], '- test_acc:', pre8[1])
print('test_loss:', pre9[0], '- test_acc:', pre9[1])
print('test_loss:', pre10[0], '- test_acc:', pre10[1])
print('test_loss:', pre11[0], '- test_acc:', pre11[1])
print('test_loss:', pre12[0], '- test_acc:', pre12[1])
print('test_loss:', pre13[0], '- test_acc:', pre13[1])
print('test_loss:', pre14[0], '- test_acc:', pre14[1])
print('test_loss:', pre15[0], '- test_acc:', pre15[1])
print('test_loss:', pre16[0], '- test_acc:', pre16[1])

model.save('CNN7-2-1123.h5')
with open('CNNlog7-2-1123.txt', 'wb') as file_txt:
    pickle.dump(history.history, file_txt)
plt.figure()
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.ylim(0.5, 1)
plt.legend(['Accuracy', "val_Accuracy"])
plt.show()

c = [1] * len(va1)
plt.figure()
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.ylim(0, 0.8)
plt.legend(['Loss', "val_Loss"])
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.show()

pred = model.predict(test_x)
pred1 = model.predict(va1)
pred2 = model.predict(va2)
pred3 = model.predict(va3)
pred4 = model.predict(va4)
pred5 = model.predict(va5)
pred6 = model.predict(va6)
pred7 = model.predict(va7)
pred8 = model.predict(va8)
pred9 = model.predict(va9)
pred10 = model.predict(va10)
pred11 = model.predict(va11)
pred12 = model.predict(va12)
pred13 = model.predict(va13)
pred14 = model.predict(va14)
pred15 = model.predict(va15)
pred16 = model.predict(va16)

plt.figure()
for i in range(len(test_x)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred[i, 0] > pred[i, 1]:
        c[i] = 0
        plt.plot(t, mc[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(test_x) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va1)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred1[i, 0] > pred1[i, 1]:
        c[i] = 0
        plt.plot(t, mc1[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc1[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va1) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va2)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred2[i, 0] > pred2[i, 1]:
        c[i] = 0
        plt.plot(t, mc2[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc2[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va2) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va3)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred3[i, 0] > pred3[i, 1]:
        c[i] = 0
        plt.plot(t, mc3[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc3[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va3) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va4)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred4[i, 0] > pred4[i, 1]:
        c[i] = 0
        plt.plot(t, mc4[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc4[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va4) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va5)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred5[i, 0] > pred5[i, 1]:
        c[i] = 0
        plt.plot(t, mc5[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc5[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va5) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va6)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred6[i, 0] > pred6[i, 1]:
        c[i] = 0
        plt.plot(t, mc6[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc6[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va6) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va7)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred7[i, 0] > pred7[i, 1]:
        c[i] = 0
        plt.plot(t, mc7[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc7[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va7) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va8)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred8[i, 0] > pred8[i, 1]:
        c[i] = 0
        plt.plot(t, mc8[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc8[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va8) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va9)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred9[i, 0] > pred9[i, 1]:
        c[i] = 0
        plt.plot(t, mc9[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc9[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va9) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va10)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred10[i, 0] > pred10[i, 1]:
        c[i] = 0
        plt.plot(t, mc10[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc10[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va10) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va11)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred11[i, 0] > pred11[i, 1]:
        c[i] = 0
        plt.plot(t, mc11[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc11[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va11) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va12)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred12[i, 0] > pred12[i, 1]:
        c[i] = 0
        plt.plot(t, mc12[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc12[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va12) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va13)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred13[i, 0] > pred13[i, 1]:
        c[i] = 0
        plt.plot(t, mc13[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc13[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va13) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va14)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred14[i, 0] > pred14[i, 1]:
        c[i] = 0
        plt.plot(t, mc14[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc14[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va14) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va15)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred15[i, 0] > pred15[i, 1]:
        c[i] = 0
        plt.plot(t, mc15[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc15[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va15) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

plt.figure()
for i in range(len(va16)):
    t = range(i * 1200, (i + 1) * 1200)
    if pred16[i, 0] > pred16[i, 1]:
        c[i] = 0
        plt.plot(t, mc16[i].reshape(1200), color='blue', linewidth=0.5)
    else:
        plt.plot(t, mc16[i].reshape(1200), color='red', linewidth=0.5)
plt.axis([0, len(va16) * 1200, None, None])
plt.xlabel('Sampling points')
plt.ylabel('Amplitude (mV)')
plt.show()

#print(end-start)